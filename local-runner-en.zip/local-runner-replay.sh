java -Xms512m -Xmx2G -server -jar "local-runner.jar" local-runner-replay.properties local-runner-replay.default.properties "$@" &
