from enum import IntEnum


class FacilityType(IntEnum):
    CONTROL_CENTER = 0
    VEHICLE_FACTORY = 1
